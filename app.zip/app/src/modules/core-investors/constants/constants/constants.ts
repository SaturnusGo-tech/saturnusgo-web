import type { Metadata } from "next";

export const CORE_INVESTORS_CTA_SECTION_ID = "cta";

export const CORE_INVESTORS_OPEN_DECK_EVENT_NAME = "open-deck";

export const CORE_INVESTORS_METADATA = {
  title: "Investors — SaturnusGo",
  description:
    "Focused investor memo for SaturnusGo: thesis, market model, business mechanics, GTM, and deck access.",
  openGraph: {
    title: "Investors — SaturnusGo",
    description: "Investor memo, market model, business mechanics, GTM, and deck access.",
    url: "https://saturnusgo.com/investors/",
    siteName: "SaturnusGo",
  },
  twitter: { card: "summary" },
} satisfies Metadata;
