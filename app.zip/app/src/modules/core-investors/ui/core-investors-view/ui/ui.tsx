"use client";

import Footer from "../../items/footer";
import ProjectionsSection from "../../sections/projections-section";
import type { CoreInvestorsViewProps } from "../../../types";
import styles from "../styles/styles.module.css";

const thesisRows = [
  {
    label: "Problem",
    text: "A city day is split across ride apps, maps, delivery, saved places, and transit.",
  },
  {
    label: "Product",
    text: "SaturnusGo connects the decision: where to go, how to move, what to save, what arrives.",
  },
  {
    label: "Wedge",
    text: "Win repeat city corridors first; expand through partners and saved places.",
  },
];

const memoRows = [
  {
    label: "Why now",
    text: "Users expect one surface. Local mobility still feels stitched together.",
  },
  {
    label: "What matters",
    text: "Frequency first: trips, places, routes, and delivery.",
  },
  {
    label: "Market logic",
    text: "Model below: SOM and non-ride streams across 3, 5, and 10 years.",
  },
  {
    label: "Next proof",
    text: "Closed cohorts must prove repeats, reliability, support quality, and paid conversion.",
  },
];

const modelRows = [
  {
    label: "Revenue",
    text: "Trip commission, delivery fees, local discovery, and partner integrations.",
  },
  {
    label: "Retention",
    text: "Saved places and repeat routes connect one use case to the next.",
  },
  {
    label: "Distribution",
    text: "Fleets, couriers, venues, route data, and communities create the first loops.",
  },
];

const roadmapRows = [
  { label: "Now", text: "Polish the surface. Run private city cohorts." },
  { label: "Next", text: "Validate supply, route quality, and delivery reliability." },
  { label: "Then", text: "Scale only when repeat behavior holds." },
];

export function CoreInvestorsView({
  onIntroCtaClick,
  onOpenDeck,
}: CoreInvestorsViewProps) {
  return (
    <div className={styles.root}>
      <section className={styles.hero} aria-labelledby="investor-title">
        <div className={styles.heroTop}>
          <span>Investor memo</span>
          <button type="button" onClick={onOpenDeck} aria-haspopup="dialog">
            Open deck
          </button>
        </div>

        <div className={styles.heroBody}>
          <p className={styles.kicker}>SaturnusGo</p>
          <h1 id="investor-title">
            City movement, in one interface.
          </h1>
          <p className={styles.lead}>
            Trips, delivery, places, and routes connected around repeated daily intent.
          </p>
          <div className={styles.heroActions}>
            <button type="button" onClick={onOpenDeck}>
              Review deck
            </button>
            <button type="button" onClick={onIntroCtaClick}>
              Request walkthrough
            </button>
          </div>
        </div>

        <div className={styles.thesisRows} aria-label="Investment thesis">
          {thesisRows.map((row) => (
            <article key={row.label} className={styles.thesisRow}>
              <span>{row.label}</span>
              <p>{row.text}</p>
            </article>
          ))}
        </div>
      </section>

      <section id="intro" className={styles.memoSection} aria-labelledby="memo-title">
        <div className={styles.sectionHead}>
          <span>Investment case</span>
          <h2 id="memo-title">The first-pass investor context.</h2>
        </div>
        <div className={styles.memoRows}>
          {memoRows.map((row) => (
            <article key={row.label} className={styles.memoRow}>
              <span>{row.label}</span>
              <p>{row.text}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.marketIntro} aria-label="Market model introduction">
        <span>Market model</span>
        <p>
          Model visible, not buried. Switch horizon; methodology shows assumptions.
        </p>
      </section>

      <ProjectionsSection />

      <section id="model" className={styles.memoSection} aria-labelledby="model-title">
        <div className={styles.sectionHead}>
          <span>Business model</span>
          <h2 id="model-title">Business mechanics without noise.</h2>
        </div>
        <div className={styles.memoRows}>
          {modelRows.map((row) => (
            <article key={row.label} className={styles.memoRow}>
              <span>{row.label}</span>
              <p>{row.text}</p>
            </article>
          ))}
        </div>
      </section>

      <section id="gtm" className={styles.memoSection} aria-labelledby="gtm-title">
        <div className={styles.sectionHead}>
          <span>GTM</span>
          <h2 id="gtm-title">Prove the loop before scaling the surface.</h2>
        </div>
        <div className={styles.memoRows}>
          {roadmapRows.map((row) => (
            <article key={row.label} className={styles.memoRow}>
              <span>{row.label}</span>
              <p>{row.text}</p>
            </article>
          ))}
        </div>
      </section>

      <section id="cta" className={styles.finalCta} aria-labelledby="cta-title">
        <span>Next step</span>
        <h2 id="cta-title">If the thesis is interesting, open the deck.</h2>
        <p>
          Full model, assumptions, methodology, and founder context.
        </p>
        <div className={styles.ctaActions}>
          <button type="button" onClick={onOpenDeck}>
            Open deck
          </button>
          <a href="/investors/methodology">Methodology</a>
          <a href="/founder">Founder</a>
        </div>
      </section>

      <Footer />
    </div>
  );
}
