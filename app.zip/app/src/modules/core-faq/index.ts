export { CoreFaqScreen } from './controllers';
