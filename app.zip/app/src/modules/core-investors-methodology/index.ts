export { CoreInvestorsMethodologyScreen } from './controllers';
