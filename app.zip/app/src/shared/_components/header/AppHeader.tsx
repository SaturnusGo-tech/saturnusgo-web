"use client";

import { useState } from "react";
import Link from "next/link";

import styles from "./header.module.css";

const NAVIGATION_LINKS = [
  { href: "/#trips", label: "Поездки" },
  { href: "/#delivery", label: "Доставка" },
  { href: "/#places", label: "Места" },
  { href: "/#transport", label: "Транспорт" },
] as const;

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const closeMobileMenu = () => setMobileMenuOpen(false);

  return (
    <header className={styles.header}>
      <div className={styles.container}>
        <Link href="/" className={styles.logo} aria-label="SaturnusGo home">
          SaturnusGo
        </Link>

        <nav className={styles.nav} aria-label="Primary navigation">
          <ul className={styles.navLinks}>
            {NAVIGATION_LINKS.map((link) => (
              <li key={link.label}>
                <Link href={link.href} className={styles.navLink}>
                  {link.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>

        <div className={styles.actions}>
          <a href="/#download-app" className={styles.downloadButton}>Скачать приложение</a>
          <button
            className={styles.mobileMenuButton}
            onClick={() => setMobileMenuOpen((value) => !value)}
            aria-label="Toggle menu"
            aria-expanded={mobileMenuOpen}
            type="button"
          >
            <span className={mobileMenuOpen ? styles.closeMark : styles.menuMark} aria-hidden />
          </button>
        </div>
      </div>

      <div className={`${styles.mobileMenu} ${mobileMenuOpen ? styles.open : ""}`}>
        <ul className={styles.mobileNavLinks}>
          {NAVIGATION_LINKS.map((link) => (
            <li key={link.label}>
              <Link href={link.href} className={styles.mobileNavLink} onClick={closeMobileMenu}>
                {link.label}
              </Link>
            </li>
          ))}
        </ul>
        <div className={styles.mobileActions}>
          <a href="/#download-app" className={styles.downloadButton} onClick={closeMobileMenu}>
            Скачать приложение
          </a>
        </div>
      </div>
    </header>
  );
}
